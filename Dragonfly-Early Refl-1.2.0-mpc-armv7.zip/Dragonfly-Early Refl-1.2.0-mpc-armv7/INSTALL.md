# Early Refl 1.2.0

Dragonfly Reverb - Early Refl

## Installation

Run as root on your MPC:

```sh
sh install.sh
```

## Manual Installation

1. Copy the contents of this package to your MPC
2. Run the install script as root
3. Restart MPC

## Files

- EarlyRefl.so - Plugin library
- Plugin Skins/ - Visual skins for the plugin
- LICENSE - GPL-3.0 license
- install.sh / uninstall.sh - Install/uninstall scripts
